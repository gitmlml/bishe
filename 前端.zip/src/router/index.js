import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'
import HomeVieww from '../views/HomeVieww.vue'
import PersonalCenter from '../views/PersonalCenter'
import MyWork from '../views/MyWork'
import PerUplode from '../views/PerUplode'
import MaterialLibrary from '../views/MaterialLibrary'
import ModelLibrary from '../views/ModelLibrary'
import SignIn from '../views/SignIn'
import RegisTer from '../views/RegisTer'
import DesignCenter from '../views/DesignCenter'
import ShowWork from '../views/ShowWork'

const routes = [
  {
    path: '/',
    name: 'home',
    component: HomeView
  },
  {
    path: '/about',
    name: 'about',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "about" */ '../views/AboutView.vue')
  },
  {
    path: '/PersonalCenter',
    name: 'PersonalCenter',
    component: PersonalCenter
  },
  {
    path: '/Mywork',
    name: 'MyWork',
    component: MyWork
  },
  {
    path: '/PerUplode',
    name: 'PerUplode',
    component: PerUplode
  },
  {
    path: '/MaterialLibrary',
    name: 'MaterialLibrary',
    component: MaterialLibrary
  },
  {
    path: '/ModelLibrary',
    name: 'ModelLibrary',
    component: ModelLibrary
  },
  {
    path: '/SignIn',
    name: 'SignIn',
    component: SignIn
  },
  {
    path: '/HomeVieww',
    name: 'HomeVieww',
    component: HomeVieww
  },
  {
    path: '/RegisTer',
    name: 'RegisTer',
    component: RegisTer
  },
  {
    path: '/DesignCenter',
    name: 'DesignCenter',
    component: DesignCenter
  },
  {
    path: '/ShowWork',
    name: 'ShowWork',
    component: ShowWork
  }
]

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
})

export default router
